# ツcore for iPhone (app)

Discord in its own app with ツcore built in (the same injector.js as the extension, loaded before Discord starts).

## Get the IPA (no Mac needed)
1. Create a new GitHub repo and upload EVERYTHING in this folder (keep the `.github` folder).
2. Open the repo > **Actions** > **Build TsuCore IPA** > **Run workflow** (it also runs on every upload).
3. When it turns green, open the run and download the artifact **TsuCore-unsigned-ipa** (unzip it to get TsuCore.ipa).
4. Sign and install TsuCore.ipa with your own tool (Sideloadly, AltStore, etc.).

If the build turns red, copy the red error text and send it to Claude.

## What the app does
- Opens discord.com/app as desktop Discord, with ツcore (Gain, Reverb, Music, Fake Deafen, LOUD, speed tick) injected.
- Allows the microphone, keeps the screen awake, keeps audio alive in the background.
- Sets the iPhone call audio session to speaker + Bluetooth in normal mode (not voice-processing mode), which may help with quiet audio.

## Limits (honest)
- It cannot go past iOS's own volume limits.
- Not tested on a real iPhone yet. Discord might behave differently in a custom WebView.
